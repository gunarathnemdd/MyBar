<?php
$servername = "localhost";
$username = "id3940083_root2";
$password = "abc123";
$dbname = "id3940083_moneymaker";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

?>